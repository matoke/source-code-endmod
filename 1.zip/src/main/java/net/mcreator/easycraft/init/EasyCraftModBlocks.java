
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.easycraft.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;

import net.mcreator.easycraft.block.EndwoodplanksBlock;
import net.mcreator.easycraft.block.EndewoodlogBlock;
import net.mcreator.easycraft.block.BlcokofendcoalBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EasyCraftModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block BLCOKOFENDCOAL = register(new BlcokofendcoalBlock());
	public static final Block ENDEWOODLOG = register(new EndewoodlogBlock());
	public static final Block ENDWOODPLANKS = register(new EndwoodplanksBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}
}
